<?php

class Dashboard extends CI_Controller
{

    public function index()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $data['barang'] = $this->m_data->tampil_data()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('user/home', $data);
        $this->load->view('templates/footer');
        $this->load->view('user/pengunjung');
    }
    public function aboutus()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('user/aboutus');
        $this->load->view('templates/footer');
        $this->load->view('user/no_hitung');
    }
    public function faq()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $this->load->view('templates/header', $data);
        $this->load->view('user/FAQ');
        $this->load->view('templates/footer');
        $this->load->view('user/no_hitung');
    }

    public function kontak()
    {
        $this->load->view('templates/header');
        $this->load->view('user/kontak');
        $this->load->view('templates/footer');
        $this->load->view('user/no_hitung');
    }

    public function search()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $keyword = $this->input->post('keyword');
        $data['barang'] = $this->m_data->get_keyword($keyword);
        $this->load->view('templates/header', $data);
        $this->load->view('user/search', $data);
        $this->load->view('templates/footer');
        $this->load->view('user/no_hitung');
    }

    public function detail_barang($id)
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $data['barang'] = $this->m_data->detail_barang($id);
        $this->load->view('templates/header', $data);
        $this->load->view('user/detail_barang', $data);
        $this->load->view('templates/footer');
        $this->load->view('user/no_hitung');
    }

    public function proses_pesan()
    {
        $data = $this->m_pesan->index();
        $this->load->view('templates/header');
        $this->load->view('user/proses_pesan', $data);
        $this->load->view('templates/footer');
        $this->load->view('user/no_hitung');
    }
    public function testimoni()
    {
        $this->load->view('templates/header');
        $this->load->view('user/testimoni');
        $this->load->view('templates/footer');
        $this->load->view('user/no_hitung');
    }
}
