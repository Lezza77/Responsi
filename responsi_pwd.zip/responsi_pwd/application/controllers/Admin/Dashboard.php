<?php

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('role_id') != '1') {
            $this->session->set_flashdata('pesan', '<div class="alert alert-danger alert-dismissible fade show" role="alert">Anda Belum Login!</div>');
            redirect('auth/login');
        }
    }
    // BARANG------------------------------------------------------------------------------------------------
    public function index()
    {
        $data = $this->m_data->ambil_data($this->session->userdata['username']);
        $data = array(
            'username' => $data->username,
        );
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/dashboard', $data);
        $this->load->view('templates_admin/footer');
    }

    public function data_barang()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $data['barang'] = $this->m_data->tampil_data()->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/data_barang', $data);
        $this->load->view('templates_admin/footer');
    }

    public function search()
    {
        $keyword = $this->input->post('keyword');
        $data['barang'] = $this->m_data->get_keyword($keyword);
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/data_barang', $data);
        $this->load->view('templates_admin/footer');
    }

    public function edit_data($id)
    {
        $where = array('id_buku' => $id);
        $data['barang'] = $this->m_data->edit_data($where, 'tb_buku')->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/edit_data', $data);
        $this->load->view('templates_admin/footer');
    }

    public function update_data()
    {
        $id = $this->input->post('id_buku');
        $judul = $this->input->post('judul');
        $pengarang = $this->input->post('pengarang');
        $tahun_terbit = $this->input->post('tahun_terbit');

        $data = array(
            'judul'  => $judul,
            'pengarang' => $pengarang,
            'tahun_terbit' => $tahun_terbit
        );
        $where = array(
            'id_buku' => $id
        );

        $this->m_data->update_data($where, $data, 'tb_buku');
        redirect('admin/dashboard/data_barang');
    }

    public function hapus_data($id)
    {
        $where = array('id_buku' => $id);
        $this->m_data->hapus_data($where, 'tb_buku');
        redirect('admin/dashboard/data_barang');
    }

    public function lihat_barang($id)
    {
        $data['barang'] = $this->m_data->detail_barang($id);
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/lihat_barang', $data);
        $this->load->view('templates_admin/footer');
    }

    public function tambah_aksi()
    {
        $judul = $this->input->post('judul');
        $pengarang = $this->input->post('pengarang');
        $tahun_terbit = $this->input->post('tahun_terbit');

        $data = array(
            'judul'  => $judul,
            'pengarang' => $pengarang,
            'tahun_terbit' => $tahun_terbit,
        );

        $this->m_data->tambah_barang($data, 'tb_buku');
        redirect('admin/dashboard/data_barang');
    }

    // Kategori------------------------------------------------------------------------------------------------
    public function kategori()
    {
        $data['kategori'] = $this->m_kategori->tampil_data()->result();
        $this->load->view('templates_admin/header');
        $this->load->view('templates_admin/sidebar');
        $this->load->view('admin/kategori', $data);
        $this->load->view('templates_admin/footer');
    }
    public function tambah_kategori()
    {
        $kategori = $this->input->post('kategori');
        $data = array(
            'kategori'  => $kategori,
        );

        $this->m_kategori->tambah_kategori($data, 'kategori');
        redirect('admin/dashboard/kategori');
    }
    public function hapus_kategori($id)
    {
        $where = array('id' => $id);
        $this->m_kategori->hapus_kategori($where, 'kategori');
        redirect('admin/dashboard/kategori');
    }

    public function hapus_pesan($id)
    {
        $where = array('id' => $id);
        $this->m_data->hapus_data($where, 'tb_pesan');
        redirect('admin/pesan');
    }

    public function xml()
    {
        $this->load->view('admin/mhs_xml');
    }
    public function json()
    {
        $this->load->view('admin/mhs_json');
    }
    public function pdf()
    {
        $this->load->view('admin/lap_mhs');
    }
}
