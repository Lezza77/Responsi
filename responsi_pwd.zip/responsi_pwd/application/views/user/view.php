<link href="<?= base_url('/assets'); ?>/css/view.css" rel="stylesheet">
<div class="containter-fluid lap1">
    <div class="card">
        <h5 class="card-header">
            Detail Barang
        </h5>
        <div class="card-body">

            <div class="row">
                <div class="col-md-4">
                    <img src="" class="card-img-top img">
                </div>
                <div class="col-md-8">
                    <table class="table">
                        <tr>
                            <td>Nama Barang</td>
                            <td><strong></strong></td>
                        </tr>
                        <tr>
                            <td>Keterangan</td>
                            <td><strong></strong></td>
                        </tr>
                        <tr>
                            <td>Kategori</td>
                            <td><strong></strong></td>
                        </tr>
                        <tr>
                            <td>Stok</td>
                            <td><strong></strong></td>
                        </tr>
                        <tr>
                            <td>Harga</td>
                            <td><strong>
                                    <div class="btn btn-sm btn-success">Rp. </div>
                                </strong></td>
                        </tr>
                    </table>
                    <?php echo anchor('dashboard/index', '<div class="btn btn-sm btn-secondary">Kembali</div>') ?>
                </div>

            </div>
        </div>
    </div>
</div>