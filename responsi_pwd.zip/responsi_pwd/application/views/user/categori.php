<link href="<?= base_url('assets'); ?>/css/home.css" rel="stylesheet">
<div class=" conten">
    <div class=" container">
        <br><br><br>
        <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?= base_url('dashboard/'); ?>">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Category</li>
            </ol>
        </nav>
        <h3 class=" text-center"><?= $judul ?></h3><br>
        <div class="row">
            <?php foreach ($barang as $brg) : ?>
                <div class="card kartu">
                    <img src="<?= base_url('assets'); ?>/img/gambar/<?php echo $brg->gambar ?>" class="card-img-top img-produk" alt="...">
                    <div class="card-body">
                        <a class="btn btn-outline-dark tombol" href="<?= base_url('dashboard/detail_barang/' . $brg->id_brg); ?>" style="width: 100%;">Rp. <?php echo number_format($brg->harga, 0, ',', '.') ?></a>
                        <p class="tulisan"><?php echo $brg->nama ?></p>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    </div>
</div>