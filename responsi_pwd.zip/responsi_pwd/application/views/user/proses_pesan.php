<link href="<?= base_url('assets'); ?>/css/kontak.css" rel="stylesheet">
<div class="containter-fluid container kontak">
  <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="<?= base_url('dashboard/'); ?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">Contact</li>
    </ol>
  </nav>
  <div class="card border-dark mb-3" style="max-width: auto;">
    <div class="card-header text-center">Contact</div>
    <div class="card-body text-dark">
      <h3>HUBUNGI KAMI</h3>
      <h3><b>Mengapa menguhubungi kami?</b></h3>
      <p>Kami memiliki komitmen untuk memberikan layanan terbaik kepada Anda dan selalu berusaha untuk menyediakan informasi dan layanan terbaik yang Anda butuhkan. Apabila untuk alasan tertentu Anda merasa tidak puas dengan pelayanan kami, Anda dapat menyampaikan kritik dan saran Anda kepada kami. Kami akan menidaklanjuti masukan yang Anda berikan dan bila perlu mengambil tindakan untuk mencegah masalah yang sama terulang kembali.</p>
      <div class="container-fluid">
        <div class="alert alert-dark">
          <p class="text-center align-middle">Pesan Anda Sudah Terkirim!</p>
        </div>
      </div>
      <div class="mb-3">
        <form action="<?= base_url('Dashboard/proses_pesan') ?>" method="post">
          <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" name="nama" class="form-control" placeholder="Nama Lengkap">
          </div>

          <div class="form-group">
            <label>Email</label>
            <input type="text" name="email" class="form-control" placeholder="Masukan Email">
          </div>

          <div class="form-group">
            <label>Pesan</label>
            <textarea type="text" name="isi" class="form-control" placeholder="Masukan Pesan"></textarea>
          </div>
          <button type="submit" class="btn btn-sm btn-dark mb-3">Kirim</button>
        </form>
      </div>
    </div>
  </div>
</div>