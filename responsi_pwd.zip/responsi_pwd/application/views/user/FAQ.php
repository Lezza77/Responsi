<link href="<?= base_url('/assets'); ?>/css/view.css" rel="stylesheet">
<div class="containter-fluid lap1">
    <div class="card border-dark mb-3" style="max-width: auto;">
        <div class="card-header text-center">FAQ</div>
        <div class="card-body text-dark">
            <h5 class="card-title">Bagaimana cara memesan barang ?<br></h5>
            <p>Pemesana dilakukan melalui WA admin kami <a href="https://api.whatsapp.com/send?phone=6281369087018&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A">+62 813-6908-7018 (SumSel)</a> atau <a href="https://api.whatsapp.com/send?phone=6282326471647&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A"> +823-2647-1647 (Lampung)</a>. Setelah melakukan pembayaran jangan lupa untuk melakukan konfirmasi pembayaran ke whatsapp kami.<br>

            <h5 class="card-tittle">Kapan barang saya sampai?</h5>
            <p>Orderan akan di proses 1-2 hari saat hari kerja, setelah pembayaran selesai atau berhasil. Waktu kerja di hari Senin sampai Jumat, Sabtu & Minggu Off.<br></p>
            <h5 class="card-title">Bisakah retur produk yang sudah dibeli?</h5>
            <p class="card-text">
                Bisa. Tapi ikuti syarat dan ketentuannya:<br>
                - Wajib melampirkan foto label pesanan yang terdapat pada packaging/bungkus produk<br>
                - Produk yang diterima terindikasi cacat/ noda<br>
                - Produk yang diterima tidak sesuai dengan yang dipesan (atau salah produk)<br>
                - Produk yang diterima tidak lengkap (atau kurang kirim)<br>
                - Wajib melampirkan video unboxing pada saat penerimaan paket utuh sampai pembukaan paket setelah difoto.<br>
                Tambahkan: Jika tidak sesuai dengan ketentuan diatas maka bukan menjadi tanggung jawab seller untuk mengganti atau melakukan pengiriman ulang.</p>
            <br><br>
        </div>
    </div>
</div>