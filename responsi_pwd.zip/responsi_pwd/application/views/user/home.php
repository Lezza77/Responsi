<link href="<?= base_url('/assets'); ?>/css/home.css" rel="stylesheet">
<!-- slide -->
<div id="carouselExampleIndicators" class="carousel slide carousel-fade" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        <div class="carousel-item active data-interval= 5000">
            <img src="<?= base_url('assets/img/slide/6.jpg') ?>" class=" w-100" alt="...">
        </div>
        <div class="carousel-item data-interval= 5000">
            <img src="<?= base_url('assets/img/slide/4.jpg') ?>" class=" w-100" alt="...">
        </div>
        <div class="carousel-item data-interval= 5000">
            <img src="<?= base_url('assets/img/slide/5.jpg') ?>" class=" w-100" alt="...">
        </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- akhir slide -->
<div class=" conten">
    <div class=" container">
        <h3 class=" text-center">Product</h3><br>
        <div class="row justify-content-center">
            <?php foreach ($barang as $brg) : ?>
                <div class="card kartu ml-3 mb-3">
                    <img src="<?= base_url('assets'); ?>/img/gambar/<?php echo $brg->gambar ?>" class="card-img-top img-produk" alt="..." style="height: 200px;">
                    <div class="card-body">
                        <a class="btn btn-outline-dark tombol" href="<?= base_url('dashboard/detail_barang/' . $brg->id_brg); ?>" style="width: 100%;">Rp. <?php echo number_format($brg->harga, 0, ',', '.') ?></a>
                        <p class="tulisan text-center"><?php echo $brg->nama ?></p>
                    </div>
                </div>
            <?php endforeach ?>
        </div>
    </div>
</div>