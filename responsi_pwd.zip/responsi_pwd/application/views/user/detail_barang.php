<link href="<?= base_url('assets'); ?>/css/detail_user.css" rel="stylesheet">
<div class="container-fluid">
    <br<br><br><br><br>
        <div class="card">
            <h5 class="card-header">
                Detail Barang
            </h5>
            <div class="card-body">
                <?php foreach ($barang as $brg) : ?>
                    <div class="row">
                        <div class="col-md-4">
                            <img style="height: 500px;" src="<?= base_url('assets'); ?>/img/gambar/<?php echo $brg->gambar ?>" class="card-img-top gambar">
                        </div>
                        <div class="col-md-8">
                            <table class="table">
                                <tr>
                                    <td>Nama Barang</td>
                                    <td><strong><?php echo $brg->nama ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Keterangan</td>
                                    <td><strong><?php echo $brg->keterangan ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Kategori</td>
                                    <td><strong><?php echo $brg->kategori ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Stok</td>
                                    <td><strong><?php echo $brg->stok ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Harga</td>
                                    <td><strong>
                                            <div class="btn btn-sm btn-success">Rp. <?php echo number_format($brg->harga, 0, ',', '.') ?></div>
                                        </strong></td>
                                </tr>
                            </table>

                            <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#pemesanan"> Info Pesan</button>

                            <?php echo anchor('dashboard/index', '<div class="btn btn-sm btn-danger">Kembali</div>') ?>
                        </div>

                    </div>
                <?php endforeach; ?>
            </div>
        </div><br>
</div>



<!-- Modal -->
<div class="modal fade" id="pemesanan" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Informasi Pemesanan</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <p for="nama">Untuk Melanjutkan Proses Pemesanan Silahkan Hubungi Admin Via Nomor Whatsapp Yang Tertertera Dibawah Ini:</p>
                        <ul>
                            <li><a href="https://api.whatsapp.com/send?phone=6281369087018&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A" class="text">+62 813-6908-7018 (Erliyana Alawiyah)</a></li>

                            <li><a href="https://api.whatsapp.com/send?phone=6282326471647&text=Assalamualaikum%20Admin%20Saya%20Mau%20Order%F0%9F%98%8A" class="text">+62 823-2647-1647 (Shabrina Anisa)</a></li>
                        </ul>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
            </form>
        </div>
    </div>
</div>