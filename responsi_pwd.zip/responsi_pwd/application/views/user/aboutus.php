<link href="<?= base_url('/assets'); ?>/css/aboutus.css" rel="stylesheet">

<!-- jumbotron -->
<div class="jumbotron jumbotron-fluid" style="	background-image: url(<?= base_url('/assets'); ?>/img/aboutus/bg.jpg);">
    <div class="container">
        <section class="logo">


            <div class="row justify-content-center">
                <div class="col-lg-6 justify-content-center d-flex">

                    <figure class="figure">
                        <img src="<?= base_url('/assets'); ?>/img//aboutus/wow1.png" alt="test 2" class="figure-img img-fluid rounded-circle">
                        <figcaption class="figure-caption">
                        </figcaption>
                    </figure>
                </div>
            </div>
        </section>
        <h1 class="display-4"><span>" SELAMAT DATANG "</span><br>
            Perpustakaan Lezza
        </h1>
    </div>
</div>
<!-- akhir jumbotron -->

<!-- container -->
<div class="container">
    <!-- panel -->

    <!-- akhir panel -->
</div>
<!-- Deskripsi -->

<!-- akhir deskripsi -->