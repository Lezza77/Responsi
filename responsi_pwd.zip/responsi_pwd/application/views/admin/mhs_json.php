<?php
include "koneksi.php";

$sql = "select * from tb_buku order by id_buku";
$tampil = mysqli_query($con, $sql);
if (mysqli_num_rows($tampil) > 0) {
    $no = 1;
    $response = array();
    $response["data"] = array();
    while ($r = mysqli_fetch_array($tampil)) {
        $h['id_buku'] = $r['id_buku'];
        $h['judul'] = $r['judul'];
        $h['pengarang'] = $r['pengarang'];
        $h['tahun_terbit'] = $r['tahun_terbit'];
        array_push($response["data"], $h);
    }
    echo json_encode($response);
} else {
    $response["message"] = "tidak ada data";
    echo json_encode($response);
}
