<div class="container-fluid">
    <h3><i class="fas fa-edit"></i>Edit Data</h3>

    <?php foreach ($barang as $brg) : ?>
        <form method="post" action="<?= base_url('admin/dashboard/update_data') ?>">
            <div class="for-group">
                <label>Judul</label>
                <input type="text" name="judul" class="form-control" value="<?php echo $brg->judul ?>">
            </div>
            <div class="for-group">
                <label>Pengarang</label>
                <input type="hidden" name="id_buku" class="form-control" value="<?php echo $brg->id_buku ?>">
                <input type="text" name="pengarang" class="form-control" value="<?php echo $brg->pengarang ?>">
            </div>
            <div class="for-group">
                <label>Tahun Terbit</label>
                <input type="text" name="tahun_terbit" class="form-control" value="<?php echo $brg->tahun_terbit ?>">
            </div>
            <!-- <div class="form-group">
            <label for="keterangan">Kategori</label>
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Pilihan</label>
                </div>
                <select class="custom-select" id="inputGroupSelect01" value="<?php echo $brg->kategori ?>">
                    <option selected></option>
                    <option value="Segi Empat">Segi Empat</option>
                    <option value="Pashmina">Pashmina</option>
                    <option value="Instan">Instan</option>
                    <option value="Segi Tiga">Segi Tiga</option>
                </select>
            </div>
        </div> -->
            <button type="submit" class="btn btn-primary btn-sm mt-5">Simpan</button>
        </form>
    <?php endforeach; ?>

</div>