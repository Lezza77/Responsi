<?php
include "koneksi.php";
header('Content-Type: text/xml');
$query = "SELECT * FROM tb_buku";
$hasil = mysqli_query($con, $query);
$jumField = mysqli_num_fields($hasil);

echo "<?xml version='1.0'?>";
echo "<data>";
while ($data = mysqli_fetch_array($hasil)) {
    echo "<tb_buku>";
    echo "<id_buku>", $data['id_buku'], "</id_buku>";
    echo "<judul>", $data['judul'], "</judul>";
    echo "<pengarang>", $data['pengarang'], "</pengarang>";
    echo "<tahun_terbit>", $data['tahun_terbit'], "</tahun_terbit>";
    echo "</tb_buku>";
}
echo "</data>";
