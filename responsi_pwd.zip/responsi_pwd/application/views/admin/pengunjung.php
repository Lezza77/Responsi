<div class="container-fluid">
    <div class="alert alert-dark" role="alert">
        <i class="fas fa-tachometer-alt mr-2"></i> Jumlah Pengunjung
    </div>
    <center>
        <div class="alert alert-dark text-center" role="alert" style="width:200px; padding-left: 20px; padding-top:23px;">
            <h4><i class="fas fa-eye"></i> <?php $count_my_page = ("Jumlah_Pengunjung.txt");
                                            $hits = file($count_my_page);
                                            $fp = fopen($count_my_page, "w");
                                            fputs($fp, "$hits[0]");
                                            fclose($fp);
                                            echo $hits[0]; ?>
        </div>
    </center>
    </h4>
</div>