<div class="container-fluid">
    <div class="alert alert-dark" role="alert">
        <i class="fas fa-tachometer-alt mr-2"></i>Data Buku
    </div>
    <button class="btn btn-sm btn-dark mb-3" data-toggle="modal" data-target="#tambah_data"><i class="fas fa-plus fa-sm"></i> Tambah BUKU</button>
    <a href=<?= base_url('admin/dashboard/xml') ?> class="btn btn-sm btn-dark mb-3"> XML</a>
    <a href=<?= base_url('admin/dashboard/json') ?> class="btn btn-sm btn-dark mb-3"> JSON</a>
    <a href=<?= base_url('admin/dashboard/pdf') ?> class="btn btn-sm btn-dark mb-3"> PDF</a>

    <table class="table table-bordered">
        <tr>
            <th>NO.</th>
            <th>JUDUL BUKU</th>
            <th>PENGARANG</th>
            <th>TAHUN TERBIT</th>
            <th style="width: 150px;">AKSI</th>
        </tr>
        <?php
        $no = 1;
        foreach ($barang as $brg) : ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= $brg->judul ?></td>
                <td><?= $brg->pengarang ?></td>
                <td><?= $brg->tahun_terbit ?></td>
                <td>
                    <?php echo anchor('admin/dashboard/edit_data/' . $brg->id_buku, '<div class="btn btn-primary btn-sm">
                    <i class="fa fa-edit"></i></div>') ?>
                    <?php echo anchor('admin/dashboard/hapus_data/' . $brg->id_buku, '<div class="btn btn-danger btn-sm">
                    <i class="fa fa-trash"></i></div>') ?>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>


<!-- Modal -->
<div class="modal fade" id="tambah_data" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">TAMBAH BUKU</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('admin/dashboard/tambah_aksi') ?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="nama">Judul Buku</label>
                        <input type="text" name="judul" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="nama">Pengarang</label>
                        <textarea type="text" name="pengarang" class="form-control"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="nama">Tahun Terbit</label>
                        <input type="text" name="tahun_terbit" class="form-control">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            </form>
        </div>
    </div>
</div>